$ErrorActionPreference = "Stop"
$project = "C:\ESP32-P4-Platform\examples\esp-idf\17_simple_video_server"
$env:IDF_TARGET = "esp32p4"
$env:IDF_COMPONENT_CACHE_PATH = "C:\idf_cache"
Set-Location $project

$ports = [System.IO.Ports.SerialPort]::GetPortNames()
if (-not $ports) {
    Write-Host "No COM port detected."
    exit 1
}

Write-Host "Detected COM ports: $($ports -join ', ')"
if ($ports.Count -eq 1) {
    $port = $ports[0]
} else {
    $port = Read-Host "Enter the ESP32 COM port (example COM13)"
}

Write-Host "Flashing on $port ..."
idf.py -p $port flash
