$ErrorActionPreference = "Stop"
$project = "C:\ESP32-P4-Platform\examples\esp-idf\17_simple_video_server"

$env:IDF_TARGET = "esp32p4"
$env:IDF_COMPONENT_CACHE_PATH = "C:\idf_cache"

Set-Location $project
Write-Host ""
Write-Host "Heimdall's Watch - Camera Subsystem"
Write-Host "Project: $project"
Write-Host "IDF_TARGET=$env:IDF_TARGET"
Write-Host "IDF_COMPONENT_CACHE_PATH=$env:IDF_COMPONENT_CACHE_PATH"
Write-Host ""
Write-Host "Detected COM ports:"
[System.IO.Ports.SerialPort]::GetPortNames()
Write-Host ""
Write-Host "Next:"
Write-Host "  idf.py build"
Write-Host "  idf.py -p COM13 flash"
Write-Host "  idf.py -p COM13 monitor"
