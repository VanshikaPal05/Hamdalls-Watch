$ErrorActionPreference = "Stop"
$project = "C:\ESP32-P4-Platform\examples\esp-idf\17_simple_video_server"
$env:IDF_TARGET = "esp32p4"
$env:IDF_COMPONENT_CACHE_PATH = "C:\idf_cache"
Set-Location $project
idf.py build
