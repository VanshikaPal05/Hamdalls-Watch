# Heimdall's Watch — Camera Subsystem

## Hardware
- Waveshare ESP32-P4-WIFI6
- Arducam OV5647 MIPI-CSI camera
- ESP32-P4 silicon revision: v1.3
- Camera interface: MIPI-CSI
- Wi-Fi coprocessor: ESP32-C6 over SDIO

## Confirmed working state
The following were confirmed working:
- ESP32-P4 boots correctly
- 32 MB PSRAM detected
- OV5647 detected over SCCB/I2C
- MIPI-CSI video path initializes
- Wi-Fi connects
- Web server starts
- Browser stream works at the ESP32 IP address

Example successful log lines:
- `ov5647: Detected Camera sensor PID=0x5647`
- `example_common: - IPv4 address: 192.168.x.x`
- `Starting stream server on port: '80'`
- `Camera web server starts`

## Project location used on the PC
`C:\ESP32-P4-Platform\examples\esp-idf\17_simple_video_server`

## Important environment variables
Every fresh ESP-IDF terminal should use:

```powershell
$env:IDF_TARGET="esp32p4"
$env:IDF_COMPONENT_CACHE_PATH="C:\idf_cache"
```

This prevents ESP-IDF from falling back to `esp32` and avoids the Windows long-path Component Manager extraction problem.

## ESP32-P4 revision
This board is ESP32-P4 revision **v1.3**.

Do NOT use `--force` if a binary says it requires v3.x silicon.

The working build must target pre-v3 / less-v3 silicon. A successful build showed:
`esp_h264: ESP32-P4 prebuilt library profile: esp32p4_less_v3`

## Camera configuration used
In `idf.py menuconfig`:

### Camera interface
- MIPI-CSI enabled
- DVP not required
- SCCB/I2C Port: 0
- SCCB Frequency: 100000
- SCL: GPIO 8
- SDA: GPIO 7
- Reset: -1
- Power Down: -1
- XCLK: -1

### OV5647
- Sensor: OV5647
- Autofocus: disabled for the fixed-focus Arducam module
- RAW8 mode used during bring-up
- ISP based video enabled
- ISP Pipeline Controller enabled
- Default IPA configuration used

## Wi-Fi configuration
Set the real SSID/password in:

`idf.py menuconfig`
→ `Example Connection Configuration`

Then set:
- WiFi SSID
- WiFi Password

Use the laptop on the same Wi-Fi/hotspot as the ESP32.

## First-time / recovery build
Open ESP-IDF terminal and run:

```powershell
cd C:\ESP32-P4-Platform\examples\esp-idf\17_simple_video_server
$env:IDF_TARGET="esp32p4"
$env:IDF_COMPONENT_CACHE_PATH="C:\idf_cache"
idf.py build
```

If the Component Manager fails with a very long AppData cache path, keep the short cache path above and clean only:
```powershell
Remove-Item -Recurse -Force build -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force managed_components -ErrorAction SilentlyContinue
idf.py build
```

Do NOT delete `sdkconfig` unless you intentionally want to reconfigure everything.

## Flashing
First close any old serial monitor. If Windows says COM is busy, kill stale Python monitor processes:

```powershell
taskkill /F /IM python.exe
taskkill /F /IM pythonw.exe
```

Then unplug/replug the board and find the current COM port:

```powershell
[System.IO.Ports.SerialPort]::GetPortNames()
```

Flash:
```powershell
idf.py -p COM13 flash
```

Replace `COM13` if Windows assigned another port.

A successful flash ends with:
- `Hash of data verified.`
- `Hard resetting via RTS pin...`
- `Done`

## Monitoring
Run separately after flashing:

```powershell
idf.py -p COM13 monitor
```

Exit monitor with:
`Ctrl + ]`

If the monitor refuses to close, kill the terminal in VS Code. The firmware on the board will keep running.

## Browser
Watch the monitor for:
`IPv4 address: 192.168.x.x`

Open:
`http://192.168.x.x`

The page should show the live camera stream.

## Common problems

### 1. `IDF_TARGET is set to esp32`
Fix:
```powershell
$env:IDF_TARGET="esp32p4"
```

### 2. COM port access denied
A stale monitor probably owns the port.
```powershell
taskkill /F /IM python.exe
```
Then unplug/replug and flash again.

### 3. No COM port
Check:
```powershell
[System.IO.Ports.SerialPort]::GetPortNames()
```
Use a tight-fitting USB data cable and a working laptop USB port.

### 4. Long-path Component Manager failure
Fix:
```powershell
$env:IDF_COMPONENT_CACHE_PATH="C:\idf_cache"
```

### 5. v3.x chip-revision error
The board is v1.3.
Do not use `--force`.
Rebuild using the pre-v3 / less-v3 configuration.

### 6. Camera not detected
Check the ribbon is in the connector marked CAMERA, not DISPLAY, and reconnect it only with power off.

## Current image-quality issue
The camera stream works, but the image currently has a strong green cast and poor color quality.

Known current status:
- camera detection works
- RAW Bayer path works
- ISP pipeline is enabled
- OV5647 driver reports Bayer order `ESP_CAM_SENSOR_BAYER_GBRG`

Image-quality tuning is the next task. Do not redo the bring-up steps above unless the subsystem stops booting.
