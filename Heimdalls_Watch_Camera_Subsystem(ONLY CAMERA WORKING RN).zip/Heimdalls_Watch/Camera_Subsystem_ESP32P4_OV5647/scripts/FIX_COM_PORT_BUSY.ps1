Write-Host "Closing stale Python serial-monitor processes..."
taskkill /F /IM python.exe 2>$null
taskkill /F /IM pythonw.exe 2>$null
Write-Host "Done. Unplug/replug the ESP32, then run 02_FLASH_CAMERA.ps1."
